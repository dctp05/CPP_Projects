using namespace std;

class Rational {
    public:
        //constructors
        Rational();
        Rational(int num1);
        Rational(int num1, int num2);

        //puts fractions into correct form
        friend void check_negatives(Rational& num1);
        
        //easier to write operator rules
        friend tuple<int, int, int, int> set_variables(const Rational& num1, const Rational& num2);

        //basic math operations
        friend Rational operator +(const Rational& num1, const Rational& num2);
        friend Rational operator -(const Rational& num1, const Rational& num2);
        friend Rational operator *(const Rational& num1, const Rational& num2);
        friend Rational operator /(const Rational& num1, const Rational& num2);
        friend Rational operator -(const Rational& num1);

        //boolean operations
        friend bool operator ==(const Rational& num1, const Rational& num2);
        friend bool operator !=(const Rational& num1, const Rational& num2);
        friend bool operator <(const Rational& num1, const Rational& num2);
        friend bool operator >(const Rational& num1, const Rational& num2);
        friend bool operator <=(const Rational& num1, const Rational& num2);
        friend bool operator >=(const Rational& num1, const Rational& num2);

        //handles instream and outstream
        friend istream& operator >>(istream& ins, Rational& rat_num);
        friend ostream& operator <<(ostream& outs, const Rational& rat_num);

    private:
        //the important stuff
        int num;
        int den;
};